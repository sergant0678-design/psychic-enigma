# İş Makinesi Bakım – Android Prototip

İlk prototip; Kotlin + Jetpack Compose ile hazırlanmıştır.

## İlk sürüm
- Ana dashboard
- Makine listesi
- Çalışma saati
- Sonraki bakım saati
- Bakım yaklaşma göstergesi
- Arıza ekranı için başlangıç
- Bakım ekranı için başlangıç

## Sonraki geliştirmeler
- Room/SQLite veritabanı
- 250/1000/2000 saat otomatik bakım hesaplama
- QR kod
- Fotoğrafla arıza kaydı
- Yedek parça/stok
- Kullanıcı/personel yetkilendirme
- Bulut senkronizasyonu
- Excel/PDF rapor
- Yönetici web paneli
